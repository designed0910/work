import time
import pyautogui
while(1):
    # 找到我要学习，并点击
    # 尝试找到屏幕上与'screenshot.png'相匹配的区域
    begin_location = pyautogui.locateOnScreen('begin.png', confidence=0.8)  # confidence参数是匹配度，可以根据需要调整

    if begin_location:
        # 如果找到了，提取坐标
        x = begin_location[0]
        y = begin_location[1]
        print(f"找到图片，坐标为 ({x}, {y})")
        # 点击该坐标（默认为左键点击）
        pyautogui.click(x, y)
    else:
        print("未找到图片")

    # 找到开始学习，并点击
    begin1_location = pyautogui.locateOnScreen('begin1.png', confidence=0.8)  # confidence参数是匹配度，可以根据需要调整

    if begin1_location:
        # 如果找到了，提取坐标
        print(begin1_location)
        x = begin1_location[0]
        y = begin1_location[1]
        print(f"找到图片，坐标为 ({x}, {y})")
        # 点击该坐标（默认为左键点击）
        # 该部分需要调节对应参数
        pyautogui.click(x + 30, y + 200)
        time.sleep(3)
        pyautogui.click(x + 30, y + 200)
    else:
        print("未找到图片")

    # 换成1-2小时
    time.sleep(3)
    # 找到原标签，并点击
    over_location = pyautogui.locateOnScreen('over.png', confidence=0.8)  # confidence参数是匹配度，可以根据需要调整

    if over_location:
        # 如果找到了，提取坐标
        print(over_location)
        x = over_location[0]
        y = over_location[1]
        print(f"找到图片，坐标为 ({x}, {y})")
        # 点击该坐标（默认为左键点击）
        pyautogui.click(x, y)
        time.sleep(3)
        pyautogui.click(x, y)
    else:
        print("未找到图片")

    # 找到F5，并点击
    f5_location = pyautogui.locateOnScreen('f5.png', confidence=0.8)  # confidence参数是匹配度，可以根据需要调整

    if f5_location:
        # 如果找到了，提取坐标
        print(f5_location)
        x = f5_location[0]
        y = f5_location[1]
        print(f"找到图片，坐标为 ({x}, {y})")
        # 点击该坐标（默认为左键点击）
        pyautogui.click(x, y)
        time.sleep(3)
        pyautogui.click(x, y)
    else:
        print("未找到图片")
    time.sleep(5)